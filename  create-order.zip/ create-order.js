// ۱. تنظیمات اتصال به دیتابیس وزارت شهرسازی و مسکن
const supabaseUrl = 'https://supabase.co';

// ⚠️ توجه: کلید طولانی Publishable key (همان که با sb_publis شروع می‌شود) را دقیقاً بین دو علامت کوتیشن زیر پیست کنید:
const supabaseKey = 'کلید_کپی_شده_از_سوپابیس_را_اینجا_پیست_کنید'; 

// ساخت کلاینت سوپابیس برای اتصال فرانت‌اند به دیتابیس
const supabase = window.supabase.createClient(supabaseUrl, supabaseKey);

document.getElementById('order-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const orderNumber = document.getElementById('order_number').value;
    const subject = document.getElementById('subject').value;
    const deadlineDate = document.getElementById('deadline_date').value;

    // ارسال داده‌ها به جدول رسمی احکام که در دیتابیس ساختیم
    const { data, error } = await supabase
        .from('ministry_orders')
        .insert([
            { 
                order_number: orderNumber, 
                subject: subject, 
                deadline_date: deadlineDate,
                status: 'in_progress' // کار در جریان است تا زمانش بگذرد یا تکمیل شود
            }
        ]);

    if (error) {
        alert("خطا در ثبت حکم: " + error.message);
        console.error(error);
    } else {
        alert("✅ حکم مقام محترم وزارت با موفقیت در سیستم ثبت شد و تعقیب هوشمند زمان آغاز گردید.");
        document.getElementById('order-form').reset();
    }
});
