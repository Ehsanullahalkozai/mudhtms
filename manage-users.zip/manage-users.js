const supabaseUrl = 'https://supabase.co';
// ⚠️ کلید Publishable key خود را بین دو علامت کوتیشن زیر پپست کنید:
const supabaseKey = 'کلید_کپی_شده_از_سوپابیس_را_اینجا_پیست_کنید'; 

const supabase = window.supabase.createClient(supabaseUrl, supabaseKey);

// بارگذاری خودکار لیست کاربرانی که تازه ثبت نام شده اند یا نیاز به ویرایش دارند
async function loadUsersToSelect() {
    const { data: users, error } = await supabase
        .from('user_profiles')
        .select('id, full_name, department_name');

    if (error) {
        console.error("خطا در دریافت لیست کاربران", error);
        return;
    }

    const select = document.getElementById('user_select');
    select.innerHTML = '<option value="">-- یک کارمند را انتخاب کنید --</option>' + 
        users.map(u => `<option value="${u.id}">${u.full_name} (${u.department_name})</option>`).join('');
}

// ثبت تغییرات تشکیلات روی کارمند انتخاب شده
document.getElementById('profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const userId = document.getElementById('user_select').value;
    const fullName = document.getElementById('full_name').value;
    const deptName = document.getElementById('department_name').value;
    const depLevel = document.getElementById('dep_level').value;
    const bast = document.getElementById('bast').value;
    const isSuperadmin = document.getElementById('is_superadmin').value === 'true';

    const { data, error } = await supabase
        .from('user_profiles')
        .update({
            full_name: fullName,
            department_name: deptName,
            dep_level: depLevel,
            bast: bast,
            is_superadmin: isSuperadmin
        })
        .eq('id', userId);

    if (error) {
        alert("خطا در ثبت تشکیلات: " + error.message);
    } else {
        alert("✅ رتبه بندی و هرم دسترسی کارمند با موفقیت ثبت شد.");
        loadUsersToSelect();
        document.getElementById('profile-form').reset();
    }
});

// اجرای اولیه برای لود کردن کاربران به محض باز شدن صفحه
document.addEventListener('DOMContentLoaded', loadUsersToSelect);
