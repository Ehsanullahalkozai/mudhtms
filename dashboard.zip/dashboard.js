// ۱. تنظیمات اتصال به دیتابیس وزارت شهرسازی و مسکن
const supabaseUrl = 'https://supabase.co';

// ⚠️ توجه: کلیدی که از بخش Publishable key در سوپابیس کپی کردید (با sb_publis شروع می‌شود) را دقیقاً بین دو علامت کوتیشن زیر پیست کنید:
const supabaseKey = 'اینجا_کلید_کپی_شده_از_سوپابیس_را_پیست_کنید'; 

// ساخت کلاینت سوپابیس برای اتصال فرانت‌اند به دیتابیس
const supabase = window.supabase.createClient(supabaseUrl, supabaseKey);

async function checkAccessAndLoadDashboard() {
  // ۲. دریافت اطلاعات کاربر فعلی که لاگین کرده است
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    alert("لطفاً ابتدا به سیستم وارد شوید.");
    return;
  }

  // ۳. خواندن پروفایل تشکیلات کاربر از دیتابیس
  const { data: profile, error } = await supabase
    .from('user_profiles')
    .select('is_superadmin, full_name, department_name')
    .eq('id', user.id)
    .single();

  if (error || !profile) {
    console.error("خطا در دریافت مشخصات اداری", error);
    return;
  }

  // ۴. مرحله ۲ نقشه راه: قفل دسترسی و Gatekeeping در فرانت‌اند
  if (profile.is_superadmin !== true) {
    // اگر کاربر عادی بود، منوی مدیریت را حذف کن و پيغام اخطار بده
    document.getElementById('admin-menu').style.display = 'none';
    document.getElementById('dashboard-content').innerHTML = `
      <div style="color: red; padding: 40px; text-align: center; background: white; border-radius: 8px;">
        <h2>🚫 خطای عدم دسترسی!</h2>
        <p>شما صلاحيت دسترسی به آمار کل وزارت و احکام محرمانه را ندارید.</p>
      </div>`;
    return;
  }

  // ۵. مرحله ۶ نقشه راه: اگر کاربر وزیر یا شما بودید -> لود اطلاعات مخصوص پراجکتور
  loadProjectorDashboardData();
}

// تابع بارگذاری لیست سیاه تأخیرها بدون تعارف (مخصوص جلسات رهبری)
async function loadProjectorDashboardData() {
  const { data: delayedOrders, error } = await supabase
    .from('ministry_orders')
    .select(`
      order_number,
      subject,
      delay_days,
      user_profiles!assigned_to (full_name, department_name, bast)
    `)
    .eq('status', 'delayed') 
    .order('delay_days', { ascending: false });

  if (error) {
    console.error("خطا در دریافت لیست تاخیرات", error);
    return;
  }

  // رندر کردن داده‌ها در جدول بزرگ برای پراجکتور
  const tableBody = document.getElementById('projector-table-rows');
  tableBody.innerHTML = delayedOrders.map(order => `
    <tr style="font-size: 20px; border-bottom: 2px solid #ccc; background-color: #fff1f1;">
      <td style="padding: 15px; font-weight: bold; color: #d32f2f;">${order.order_number}</td>
      <td style="padding: 15px;">${order.subject}</td>
      <td style="padding: 15px; font-weight: bold;">${order.user_profiles?.department_name || 'نامشخص'}</td>
      <td style="padding: 15px; color: #555;">${order.user_profiles?.full_name || 'بدون مسئول'} (بست ${order.user_profiles?.bast || '-'})</td>
      <td style="padding: 15px; background-color: #ffcdd2; color: #b71c1c; font-weight: bold; text-align: center;">
        ⚠️ ${order.delay_days} روز تأخیر
      </td>
    </tr>
  `).join('');
}

// به محض باز شدن صفحه، عملیات بررسی را شروع کن
document.addEventListener('DOMContentLoaded', checkAccessAndLoadDashboard);
